﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Timer : MonoBehaviour
{
    // Start is called before the first frame update


    // default total time
    [SerializeField]
    public int totalTime = 3;
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        // if (totalTime)
    }
}


// 1. countdown totaltime 
