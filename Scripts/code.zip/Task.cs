﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Task : MonoBehaviour
{

    [SerializeField] public Material texture;
    [SerializeField] public string taskName;

    [SerializeField] public bool isVideo = false;

    // whether if task could follow user or not
    [SerializeField] public bool needFollowing = false;

    [SerializeField] public UnityEngine.Video.VideoClip videoClip;

    private UnityEngine.Video.VideoPlayer m_VideoPlayer;

    private int onDeviceNum = -1;

    private bool isRunning = false;


    // Start is called before the first frame update
    void Start()
    {
        if (isVideo) {
            HandleVideoTexture();
        }
    }

    // Update is called once per frame
    void Update()
    {
        // Debug.Log(m_VideoPlayer.isPlaying);
    }

    public void SetDevice(int deviceNum) {
        onDeviceNum = deviceNum;
    }

    public int GetDevice() {
        return onDeviceNum;
    }

    void HandleVideoTexture() {
        // TODO: video handler needed after basic function completed
        m_VideoPlayer = gameObject.GetComponent<UnityEngine.Video.VideoPlayer>();
        // m_VideoPlayer.renderMode = UnityEngine.Video.VideoRenderMode.MaterialOverride;
    }

    public void PlayVideo() {
        m_VideoPlayer.Play();
    }

    public void PauseVideo() {
        m_VideoPlayer.Pause();
    }
}