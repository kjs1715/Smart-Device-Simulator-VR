﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Microsoft.MixedReality.Toolkit;

public class UserState : MonoBehaviour
{
    
    // state for user is moving or not
    public bool isMoving;
    public bool isStanding; // TODO: need to calibrate threshold of standing height

    const float userHeightThres = 0.5f;

    // first gaze needed
    bool isFirstGaze = true;

    Vector3 lastUserPos;
    Vector3 curUserPos;
    GameObject lastDeviceGazed;

    public GameObject grabbedDevice {
        set {
            // Debug.Log(value.name);
            _grabbedDevice = value;
        }
    }

    GameObject _grabbedDevice;

    void Start() {
        isMoving = false;
        lastUserPos = this.getUserPosition();
        _grabbedDevice = null;
    }

    void Update() {
        DetectUserMoving();
        DetectUserStanding();
        // Debug.Log("isMoving :" + isMoving);
        // Debug.Log("isStanding :" + isStanding);


    }



    public Vector3 getUserDirection() {
        return CoreServices.InputSystem.GazeProvider.GazeDirection;
    }

    public Vector3 getUserPosition() {
        return CoreServices.InputSystem.GazeProvider.GazeOrigin;
    }

    
    // only returns display devices
    // P.S. Need to gaze at least one device when the system is intitialized
    public GameObject getGazingObject(out int deviceNum, out string deviceName) {
        // Test: Solving problem for no device gazed at first time
        if (isFirstGaze) {
            deviceNum = 0;
            deviceName = DeviceDetector._devices[0].name;
            lastDeviceGazed = DeviceDetector._devices[0];
            isFirstGaze = false;
            return lastDeviceGazed;
        }

        deviceNum = -1;
        deviceName = "";
        if (CoreServices.InputSystem.GazeProvider.GazeTarget) {
            for (int i = 0; i < DeviceDetector.getDeviceCount(); i++) {
                GameObject temp = CoreServices.InputSystem.GazeProvider.GazeTarget;
                if (temp == DeviceDetector._devices[i]) {
                    deviceNum = i;
                    deviceName = temp.name;
                    lastDeviceGazed = temp;
                    return temp;
                }
            }
        }
        return lastDeviceGazed;
    }


    public void DetectUserMoving() {
        // detect user movement
        curUserPos = getUserPosition();
        var displacement = curUserPos - lastUserPos;
        lastUserPos = curUserPos;

        if (displacement.magnitude > 0.001) {
            isMoving = true;
            return ;
        }
        isMoving = false;
    }

    public void DetectUserStanding() {
        // detect user standing
        curUserPos = getUserPosition();
        if (curUserPos.y >= 0.5) {
            isStanding = true;
            return ;
        }
        isStanding = false;
    }

    public void DetectViewportDevice() {
        
    }

    public void DetectEventObjects() {
        // ray ground detection
        // Ray ray = new Ray(getUserPosition(), Vector3.down);
        RaycastHit hit;
        Physics.Raycast(getUserPosition(), Vector3.down, out hit);
        if (hit.collider.tag == "Event Objects") {
            Debug.Log("Event Object detected");
        }
    }

    // public
}