﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TaskManager : MonoBehaviour
{

    public ArrayList taskList;
    public ArrayList waitList;
    public Queue<Task> newTaskQueue;
    int lastCount;



    // manage all event trigger objects
    GameObject[] eventObjList;


    // Start is called before the first frame update
    void Start()
    {
        taskList = new ArrayList();
        waitList = new ArrayList();
        newTaskQueue = new Queue<Task>();
        lastCount = taskList.Count;
        // eventObjList = GameObject.FindGameObjectsWithTag("Event Objects");
    }

    // Update is called once per frame
    void Update()
    {
        /*
            TODO: Do in context manager?
                1. Check TaskQueue
                2. if Task
                    2.1 Check device availability
                    2.2 if available
                        put task
        */

        
    }

    public bool CheckNewTask() {
        // if (taskList.Count != lastCount) {
        //     lastCount = taskList.Count;
        //     return true;
        // }
        if (newTaskQueue.Count > 0) {
            return true;
        }
        return false;   
    }

    public bool CheckWaitTask() {
        if (waitList.Count > 0) {
            return true;
        }
        return false;
    }

    public void CallingTask(Task task) {
        Debug.Log("task called");
        Debug.Log(task.taskName + " started");
        // taskList.Add(task);
        newTaskQueue.Enqueue(task);
    }

    public void RemoveTask(Task task) {
        Debug.Log("task removed");
        Debug.Log(task.taskName + " ended");
        if (taskList.Contains(task)) {
            task.PauseVideo();
            taskList.Remove(task);
        }
    }

}

