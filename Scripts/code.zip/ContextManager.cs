﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Microsoft.MixedReality.Toolkit;
using System.Linq;
using System;



public class ContextManager 
{
    // variables
    UserState userState;
    TaskManager taskManager;
    // float[] user2deviceAngle;
    Dictionary<int, float> user2deviceDistance;
    Dictionary<int, float> user2deviceAngle;


    // 1:35
    const float _dis = 3.0f;
    // const float camera_dis = 20.0f;
    const float camera_dis = 24.0f;

    // renderScene variables
    GameObject textCamera;
    float m_dis;

    // based on distance
    float dis_threshold {
        //TODO: not natural when user get close to the device
        set {
            if (value < _dis && value > 0) {
                float temp = -((_dis - value) * camera_dis);
                // Debug.Log(temp);
                textCamera.transform.position = new Vector3(textCamera.transform.position.x, textCamera.transform.position.y, -99.68f + temp);
            }
        }
    }

    

    int targetDeviceNum;
    string targetDeviceName;
    int currentDeviceNum;
    string currentDeviceName;

    // gazing target
    int currentGazingNum;
    string currentGazingName;
    int targetGazingNum;
    string targetGazingName;

    // User direction
    int targetDirectionNum;



    // test variables
    Vector3 testVector1, testVector2;
    string[] device_dis;


    public ContextManager(GameObject userState_obj, GameObject taskEvent_obj) {
        userState = userState_obj.GetComponent<UserState>();
        taskManager = taskEvent_obj.GetComponent<TaskManager>();
        // if (userState == null) {
        //     Debug.Log("None");
        // }

        user2deviceDistance = new Dictionary<int, float>();
        user2deviceAngle = new Dictionary<int, float>();
        for (int i = 0; i < DeviceDetector.getDeviceCount(); i++) {
            user2deviceAngle.Add(i, 0.0f);
            user2deviceDistance.Add(i, 0.0f);
        }

        // init target device and save initial devices dis
        this.getDistance();
        // targetDeviceNum = user2deviceDistance.Keys[0];

        // float dis = this.getNearestUser2deviceDistance(out targetDeviceNum, out targetDeviceName);
        // currentDeviceNum = targetDeviceNum;
        // currentDeviceName = targetDeviceName;
        // DeviceDetector.setTexture(ResourcesManager.textRenderTexture, currentDeviceNum);

        // save textCamera initial position
        textCamera = DeviceDetector._cameras[0];



    }

    /*
        Update all kinds of context variables
    */
    public void DetectContext() {

        // detect device availability
        DeviceDetector.DetectAvailability();

        // Dectect user context
        DetectUserContext();


        // TODO: detect waiting task
        // if ()

        // detect task
        if (taskManager.CheckNewTask()) {
            AttachTask(taskManager.newTaskQueue.Dequeue());
            // check queue is empty
            foreach (Task task in taskManager.newTaskQueue) {
                Debug.Log(task);
            }
        }

        Schedule();
        
        // user direction 
        // using GazeProvider
        // Debug.Log(userState.getUserPosition());
        // Debug.Log(userState.getUserDirection());



        // all distance output (use to test)
        // 
        // float[] dis1 = this.getUser2deviceDistance(out device_dis);

        // for (int i = 0; i < DeviceDetector.getDeviceCount(); i++) {
        //     Debug.Log(device_dis[i]);
        //     Debug.Log(dis1[i]);
        // }


        // text size change with distance
        if (currentDeviceNum != -1) {
            dis_threshold = user2deviceDistance[currentDeviceNum];
        }

        // detect user movement
        // Debug.Log("isMoving" + userState.isMoving);

    
        // Debug.Log(userState.getUserDirection());
        // Debug.Log("Angle2 : " + Vector3.Angle(userState.getUserDirection(), testVector2));


    }

    public void DetectUserContext() {
        // Angle part
        this.getUser2deviceAngles();
        this.getDistance();

        // Eye gaze part (done)
        userState.getGazingObject(out targetGazingNum, out targetGazingName);
        // Debug.Log("Gazing num :" + targetGazingNum);
        if (targetGazingNum != currentGazingNum) {
            // DeviceDetector.setTexture(ResourcesManager.textRenderTexture, targetDeviceNum);
            // DeviceDetector.setTexture(ResourcesManager.emptyScreenTexture, currentDeviceNum);
            currentGazingNum = targetGazingNum;
            currentGazingName = targetGazingName;  
            
        }


        
        // Min distance part (done)

        // first time need to set current device
        // 1. getDistances
        // 2. min(Dis)
        // 3. then select Device to schedule
        this.getDistance();
        // float dis = this.getNearestUser2deviceDistance(out targetDeviceNum, out targetDeviceName);
        // Debug.Log("target :" + targetDeviceNum);
        // Debug.Log("current :" + currentDeviceNum);
        if (targetDeviceNum != currentDeviceNum) {
            // need to change target first and turn current black 

            // DeviceDetector.setTexture(ResourcesManager.textRenderTexture, targetDeviceNum);
            // DeviceDetector.setTexture(ResourcesManager.emptyScreenTexture, currentDeviceNum);
            currentDeviceNum = targetDeviceNum;
            currentDeviceName = targetDeviceName;
        }

    }

    public void Schedule() { // TODO: need to check waitlist
        // first ver.
        // 1. calculate angle between running device and user (all?) DONE
        // 2. if task angle < 150
        //  2.1 find 2 nearest device (in main function) DONE
        //  2.2 check availability
        //      2.2.1 if not empty (two device)
        //      2.2.2 waitList
        //      2.2.3 break
        //  2.3 compare angle

  
        foreach (Task task in taskManager.taskList) {
            if (user2deviceAngle[task.GetDevice()] < 145) {
                Debug.Log("Scheduling task " + task.name + "...");
                // int type = DeviceDetector.Nearest2DeviceAvailable();
                bool Changed = false;
                int count = 0;
                var enumerator = user2deviceDistance.GetEnumerator();
                while (enumerator.MoveNext() && count < 2) {
                    int deviceNum = enumerator.Current.Key;
                    if (task.GetDevice() == deviceNum) 
                        continue ;
                    if (DeviceDetector._available[deviceNum]) {
                        Debug.Log("Device " + DeviceDetector._devices[deviceNum].name + " available!");
                        if (user2deviceAngle[deviceNum] >= 150) {
                            DeviceDetector.ChangeTexture(task.GetDevice(), deviceNum, task.texture);
                            task.SetDevice(deviceNum);
                            Changed = true;
                            break ;
                        }
                    }
                    count++;
                }
                if (!Changed) {
                    taskManager.waitList.Add(task);
                }

            }
        }
    }

    // for new task allocation, then schedule all devices
    public void AttachTask(Task task) {

        //TEST
        // for (int i = 0; i < DeviceDetector.getDeviceCount(); i++) {
        //     Debug.Log(DeviceDetector._devices[i].name + " " + DeviceDetector._available[i]);
        // }
        if (task.isVideo) {
            task.PlayVideo();
            Debug.Log("Played?");
        }

        int NearestDevice = user2deviceDistance.First().Key;
        Debug.Log("Attach : " + DeviceDetector._devices[NearestDevice] + " " + DeviceDetector._available[NearestDevice]);
        if (DeviceDetector._available[NearestDevice]) {
            Debug.Log("Attached?");
            DeviceDetector._available[NearestDevice] = false;
            task.SetDevice(NearestDevice);
            DeviceDetector.setTexture(task.texture, NearestDevice);
            taskManager.taskList.Add(task);
            return ;
        }
        // TODO: if not available? what to do next?


        //TEST
        // for (int i = 0; i < DeviceDetector.getDeviceCount(); i++) {
        //     Debug.Log(DeviceDetector._devices[i].name + " " + DeviceDetector._available[i] + " " + user2deviceAngle[i] + " " + user2deviceDistance[i]);
        // }
        
    }
    /// <summary>
    /// Sorted distance between user and devices
    /// </summary>
    public Dictionary<int, float> getDistance() {
        for (int i = 0; i < DeviceDetector.getDeviceCount(); i++) {
            user2deviceDistance[i] = Vector3.Distance(userState.getUserPosition(), DeviceDetector._devices[i].transform.position);
        }
        user2deviceDistance = user2deviceDistance.OrderBy(i => i.Value).ToDictionary(k => k.Key, v => v.Value);
        // for (int i = 0; i < user2deviceDistance.Length; i++) {
        //     Debug.Log(DeviceDetector._devices[i].name + " " + user2deviceDistance[i]);
        // }
        return user2deviceDistance;
    }

    // public float[] getUser2deviceDistance(out string[] deviceNames) {
    //     deviceNames = new string[DeviceDetector.getDeviceCount()];
    //     for (int i = 0; i < DeviceDetector.getDeviceCount(); i++) {
    //         deviceNames[i] = DeviceDetector._devices[i].name;
    //     }
    //     return user2deviceDistance;
    // }

    // public float getNearestUser2deviceDistance(out int deviceNum, out string deviceName) {
    //     // Dictionary<string, float> nearest = new Dictionary<string, float>();
    //     deviceNum = -1;
    //     deviceName = "";
    //     float dis = user2deviceDistance.Min();
    //     for (int i = 0; i < DeviceDetector.getDeviceCount(); i++) {
    //         if (dis == user2deviceDistance[i]) {
    //             deviceName = DeviceDetector._devices[i].name;
    //             deviceNum = i;
    //             break;
    //         }
    //     }
    //     return dis;
    //     // nearest.Add(deviceName, dis);
    //     // return nearest;
    // }

    public Dictionary<int, float> getUser2deviceAngles() {
        for (int i = 0; i < DeviceDetector.getDeviceCount(); i++) {
           Transform[] transforms = DeviceDetector._devices[i].GetComponentsInChildren<Transform>();
            foreach (Transform tf in transforms) {
                if (tf.name == "Screen") { 
                    user2deviceAngle[i] = Vector3.Angle(userState.getUserDirection(), tf.up);
                    break;
                }
            }
        }
        // sort here?
        user2deviceAngle = user2deviceAngle.OrderBy(i => i.Value).ToDictionary(k => k.Key, v => v.Value);
        return user2deviceAngle;
    }


    // public void initCameraPosition(int cameraNum) {
    //     DeviceDetector._cameras[cameraNum].transform.position = textCamera;
    // }

    public void adjustTextDis() {
        // TODO: Maybe need to make a new class to manage all textureScenes

    }



    ///<summary>
    /// Use to calculate angles between user and devices: NOW JUST FOR TEST
    ///</summary>
    public void CalculateAngles() {
        // for (int i = 0; i < )
    }

}
