using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;

/*
    Detect all devices in the environment. All display devices are tagged with "Displays"
*/
public class DeviceDetector {

    // test texture


    static public GameObject[] _devices;
    static public GameObject[] _cameras;
    static public GameObject[] _screens;
    static public bool[] _available;
    static public bool[] _inUserSight;

    static public Dictionary<int, GameObject> _devicesDict;


    static TMP_Dropdown _deviceSelector;

    // Material[] _materials;

    static int deviceCount = 0;
    static int deviceSelected;


    static public void Init() {

        // set all devices
        _devices = FindDisplays();
        _cameras = FindCameras();
        deviceCount = _devices.Length;
        deviceSelected = deviceCount;   // means all devices, otherelse, the value represents each device

        _available = new bool[deviceCount];
        _inUserSight = new bool[deviceCount];
        _devicesDict = new Dictionary<int, GameObject>();

        for (int i = 0; i < deviceCount; i++) {
            _available[i] = false;
            _inUserSight[i] = false;
            _devicesDict.Add(i, _devices[i]);
        }
        //TODO: have to check available or not : DONE
        
       
    }

    static public GameObject[] FindDisplays() {
        return GameObject.FindGameObjectsWithTag("Displays");
    }

    static public GameObject[] FindCameras() {
        return GameObject.FindGameObjectsWithTag("Cameras");
    }

    static public void FindDeviceSelector(TMP_Dropdown tMP_Dropdown) {
        _deviceSelector = tMP_Dropdown;
    }

    static public void DetectAvailability() {
        for (int i = 0; i < deviceCount; i++) {
            MeshRenderer[] meshRenderers = _devices[i].GetComponentsInChildren<MeshRenderer>();
            foreach (MeshRenderer meshRenderer in meshRenderers) {
                // set availability
                if (meshRenderer.name == "Screen") {

                    // modified: comparing with color 
                    if (meshRenderer.material.color == ResourcesManager.emptyScreenTexture.color) {
                        _available[i] = true;
                    } else {
                        _available[i] = false;
                    }
                }

            }
        }
        // for (int i = 0; i < deviceCount; i++) {
        //     Debug.Log(_available[i]);
        // }

    }


/*
    Change texture in single device
*/
    static public void setTexture(Material material, int deviceNum) {
        if (deviceNum == -1) return ;
        MeshRenderer[] meshRenderers = _devices[deviceNum].GetComponentsInChildren<MeshRenderer>();
        foreach (MeshRenderer meshRenderer in meshRenderers) {
            if (meshRenderer.name == "Screen") {
                Debug.Log("Screen changed");
                meshRenderer.material = material;       
                break;
            }
        }   
    }

/*
    Change every texture in each device
*/
    static public void setTextureAll(Material material) {
        // test changing texture
        for (int i = 0; i < deviceCount; i++) {
            MeshRenderer[] meshRenderers = _devices[i].GetComponentsInChildren<MeshRenderer>();
            foreach (MeshRenderer meshRenderer in meshRenderers) {
                if (meshRenderer.name == "Screen") {
                    // Debug.Log("Screen changed");
                    meshRenderer.material = material;
                    break;
                }
            }

        }
    }

    /// <summary>
    /// Check the 2 Nearest devices availability
    /// </summary>
    /// <returns></returns>
    static public int Nearest2DeviceAvailable() {
        if (_available[0] || _available[1]) {
            if (!_available[0]) return 1;
            else if (!_available[1]) return 0;
            else return 2;
        }
        return -1;
    }

    static public void ChangeTexture(int src, int dst, Material texture) {
        _available[src] = true;
        _available[dst] = false;
        DeviceDetector.setTexture(texture, dst);
        DeviceDetector.setTexture(ResourcesManager.emptyScreenTexture, src);
    }



    // initialize Device selector menu
    static public void setDeviceOptions() {        
        // Example();
        for (int i = 0; i < deviceCount; i++) {
            // Debug.Log(_devices[i].name);
            _deviceSelector.options.Add(new TMPro.TMP_Dropdown.OptionData() {text = _devices[i].name});
        }
        _deviceSelector.options.Add(new TMPro.TMP_Dropdown.OptionData() {text = "All"});

    }

    static public int getDeviceSelected() {
        deviceSelected = _deviceSelector.value;
        Debug.Log(deviceSelected);
        return deviceSelected;
    }

    static public int getDeviceCount() {
        return deviceCount;
    }

    static IEnumerator Example() {
        yield return new WaitForSeconds(5);
    }



}

