﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CallingEventClick : MonoBehaviour
{
    /*
        Start calling task when triggered

        phone needs a specific texture

    
    */
    void Start() {
        
    }

    public void Click(){
        
    }
}
