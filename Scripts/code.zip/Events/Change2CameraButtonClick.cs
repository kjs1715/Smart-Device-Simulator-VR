﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Change2CameraButtonClick : MonoBehaviour
{
    [SerializeField]
    public Material cameraTexture;
    public void Click() {
        int deviceNum = DeviceDetector.getDeviceSelected();
        if (deviceNum == DeviceDetector.getDeviceCount()) {
            DeviceDetector.setTextureAll(cameraTexture);
        } else {
            DeviceDetector.setTexture(cameraTexture, deviceNum);
        }
    }
}
