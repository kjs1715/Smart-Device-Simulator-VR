﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Change2VideoButtonClick : MonoBehaviour
{
    [SerializeField]
    public Material videoTexture;
    public void Click() {
        int deviceNum = DeviceDetector.getDeviceSelected();
        if (deviceNum == DeviceDetector.getDeviceCount()) {
            DeviceDetector.setTextureAll(videoTexture);
        } else {
            DeviceDetector.setTexture(videoTexture, deviceNum);
        }
    }
}
